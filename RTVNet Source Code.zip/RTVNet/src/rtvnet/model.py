"""RTV-Net in PyTorch. Read numbered comments for the forward-pass steps.
Fixed pattern construction follows the supplied GPL-3.0 LITEMV reference.
This is an adaptation, not a bit-for-bit reproduction of original LITEMV.
"""
import torch
from torch import nn
from torch.nn import functional as F

class SameConv(nn.Module):
    """Explicit asymmetric SAME padding, including even kernels and dilation."""
    def __init__(self, cin, cout, kernel, dilation=1, groups=1):
        super().__init__()
        self.pad = dilation * (kernel - 1)
        self.conv = nn.Conv1d(cin, cout, kernel, dilation=dilation,
                              groups=groups, bias=False)
    def forward(self, x):
        return self.conv(F.pad(x, (self.pad//2, self.pad-self.pad//2)))

class SepConv(nn.Sequential):
    def __init__(self, cin, cout, kernel, dilation=1):
        super().__init__(SameConv(cin,cin,kernel,dilation,cin),
                         nn.Conv1d(cin,cout,1,bias=False))

class FixedPatterns(nn.Module):
    """Frozen increasing/decreasing/peak filters, applied per feature channel."""
    def __init__(self, channels, sizes=(2,4,8,16,32,64)):
        super().__init__()
        kernels=[]
        for sign in (1.,-1.):
            for k in sizes:
                v=torch.ones(k); v[::2]=-1
                kernels.append(sign*v)
        for k in sizes[1:]:
            a=torch.linspace(0,1,k//4+1)[1:].square()
            kernels.append(torch.cat([-a,-a.flip(0),2*a,2*a.flip(0),-a,-a.flip(0)]))
        self.channels=channels; self.names=[]
        for i,v in enumerate(kernels):
            name=f'kernel_{i}'; self.register_buffer(name,v[None,None].repeat(channels,1,1))
            self.names.append(name)
        self.out_channels=channels*len(kernels)
    def forward(self,x):
        outputs=[]
        for name in self.names:
            w=getattr(self,name); p=w.shape[-1]-1
            outputs.append(F.conv1d(F.pad(x,(p//2,p-p//2)),w,groups=self.channels))
        return F.relu(torch.cat(outputs,dim=1))

class TVEM(nn.Module):
    def __init__(self,width=8,smooth=5):
        super().__init__(); self.smooth=smooth
        self.trend=nn.Sequential(SameConv(1,width,5),nn.BatchNorm1d(width),nn.ReLU())
        self.variation=nn.Sequential(SameConv(1,width,5),nn.BatchNorm1d(width),nn.ReLU())
        self.gate=nn.Conv1d(2*width,width,1)
    def forward(self,x,m,v,vm):
        # STEP 1. Smooth only observed values; never count numerical gap fills.
        k=self.smooth
        numerator=F.avg_pool1d(x*m,k,1,k//2,count_include_pad=False)
        denominator=F.avg_pool1d(m,k,1,k//2,count_include_pad=False)
        sm=numerator/denominator.clamp_min(1e-8)
        mt=m*(denominator>0); mv=m*vm
        # STEP 2. Use separate trainable branch encoders with identical shapes.
        ht=self.trend(sm)*mt; hv=self.variation(v*mv)*mv
        gate=torch.sigmoid(self.gate(torch.cat([ht,hv],dim=1)))
        # STEP 3. Fuse supported branches. Fall back to one branch if necessary.
        both=mt*mv
        z=(gate*ht+(1-gate)*hv)*both + ht*mt*(1-mv)+hv*mv*(1-mt)
        return z, torch.maximum(mt,mv),gate

class Backbone(nn.Module):
    def __init__(self,cin,width=16,custom=True):
        super().__init__()
        self.learned=nn.ModuleList([SepConv(cin,width,k) for k in (40,20,10)])
        self.fixed=FixedPatterns(cin) if custom else None
        n=3*width+(self.fixed.out_channels if custom else 0)
        self.norm=nn.BatchNorm1d(n)
        self.stage2=nn.Sequential(SepConv(n,width,20,2),nn.BatchNorm1d(width),nn.ReLU())
        self.stage3=nn.Sequential(SepConv(width,width,10,4),nn.BatchNorm1d(width),nn.ReLU())
    def forward(self,x,m):
        # STEP 4. Fixed and learned filter banks run in PARALLEL, not serially.
        paths=[f(x*m) for f in self.learned]
        if self.fixed is not None: paths.append(self.fixed(x*m))
        h=F.relu(self.norm(torch.cat(paths,dim=1)))*m
        h=self.stage2(h)*m
        return self.stage3(h)*m

class ERFM(nn.Module):
    def __init__(self,width,qdim=3,hidden=8):
        super().__init__()
        self.mlp=nn.Sequential(nn.Linear(width+qdim,hidden),nn.ReLU(),nn.Linear(hidden,1))
    def forward(self,features,available,quality):
        # features B,C,D,T; available B,C,T; quality B,C,3.
        # STEP 5. Pool descriptors in time, then estimate one logit per window/electrode.
        h=(features*available[:,:,None]).sum(-1)/available.sum(-1).clamp_min(1)[:,:,None]
        logits=self.mlp(torch.cat([h,quality],dim=-1)).squeeze(-1)
        # STEP 6. Stable softmax over electrodes at each valid timestep.
        expanded=logits[:,:,None].expand_as(available)
        masked=expanded.masked_fill(available<=0,-1e9)
        weights=torch.softmax(masked,dim=1)*available
        weights=weights/weights.sum(1,keepdim=True).clamp_min(1e-8)
        fused=(features*weights[:,:,None]).sum(1)
        return fused, weights, logits

class RTVNet(nn.Module):
    def __init__(self,tvem=True,erfm=True,branch_width=8,width=16,hidden=8,custom=True):
        super().__init__(); self.use_tvem=tvem; self.use_erfm=erfm
        self.tvem=TVEM(branch_width) if tvem else None
        self.backbone=Backbone(branch_width if tvem else 1,width,custom)
        self.erfm=ERFM(width,hidden=hidden) if erfm else None
        self.classifier=nn.Linear(width,2)
    def forward(self,x,mask,diff,diff_mask,quality,return_aux=False):
        b,c,t=x.shape; m=mask.reshape(b*c,1,t)
        if self.use_tvem:
            z,a,g=self.tvem(x.reshape(b*c,1,t),m,diff.reshape(b*c,1,t),diff_mask.reshape(b*c,1,t))
        else:
            z=x.reshape(b*c,1,t)*m; a=m; g=None
        features=self.backbone(z,a).reshape(b,c,-1,t)
        available=a.reshape(b,c,t)
        if self.use_erfm:
            fused,weights,logits=self.erfm(features,available,quality)
            valid=available.sum(1)>0
            u=(fused*valid[:,None]).sum(-1)/valid.sum(-1).clamp_min(1)[:,None]
            out=self.classifier(u)
            probs=torch.softmax(out,dim=-1)
        else:
            # Fair no-ERFM ablation: mean per-electrode class probabilities.
            pooled=(features*available[:,:,None]).sum(-1)/available.sum(-1).clamp_min(1)[:,:,None]
            ep=torch.softmax(self.classifier(pooled),dim=-1)
            good=(available.sum(-1)>0).float()
            probs=(ep*good[:,:,None]).sum(1)/good.sum(1).clamp_min(1)[:,None]
            probs=torch.where(good.sum(1)[:,None]>0,probs,torch.full_like(probs,.5))
            out=torch.log(probs.clamp_min(1e-8))
            weights=available/available.sum(1,keepdim=True).clamp_min(1)
            fused=(features*weights[:,:,None]).sum(1); logits=None
        # STEP 7. No electrode available: expose failure; return neutral probability.
        valid_window=available.sum((1,2))>0
        probs=torch.where(valid_window[:,None],probs,torch.full_like(probs,.5))
        if return_aux:
            return {'probabilities':probs,'features':features,'weights':weights,
                    'reliability_logits':logits,'gate':g,'valid_window':valid_window,
                    'fused':fused}
        return probs

VARIANTS={'rtvnet':(True,True),'backbone':(False,False),
          'tvem_only':(True,False),'erfm_only':(False,True)}
def build_model(variant='rtvnet',**kwargs):
    if variant not in VARIANTS: raise ValueError(f'Unknown variant {variant}')
    t,e=VARIANTS[variant]; return RTVNet(tvem=t,erfm=e,**kwargs)
