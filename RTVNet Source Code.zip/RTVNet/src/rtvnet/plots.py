"""Export figures from ACTUAL model outputs. Every synthetic input is visibly labelled."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from .data import load_windows
from .engine import load_checkpoint,batch,aggregate,metrics,require_checkpoint_dataset

plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif','DejaVu Serif'],'font.size':11})

def explain(path,checkpoint,out,window_index=None):
    a,meta=load_windows(path);model,scaler,cp=load_checkpoint(checkpoint)
    require_checkpoint_dataset(cp,a,meta)
    test=[i for i,w in enumerate(meta['metadata']) if w['plant_id'] in cp['test_plants']]
    if not test:raise ValueError('No held-out windows for this checkpoint')
    i=test[0] if window_index is None else window_index
    if i not in test:raise ValueError('Explanation must use a held-out plant for this checkpoint')
    train=[j for j,w in enumerate(meta['metadata']) if w['plant_id'] in cp['train_plants']]
    if not train:raise ValueError('Training windows required to compute training-only response scale')
    scaled=scaler.transform(a);responses=[]
    with torch.no_grad():
        for start in range(0,len(train),32):
            ix=train[start:start+32];aux=model(*batch(scaled,ix,'cpu'),return_aux=True)
            rr=aux['features'].square().mean(2).sqrt().numpy()
            responses.extend(rr[a['mask'][ix]>0].tolist())
        aux=model(*batch(scaled,[i],'cpu'),return_aux=True)
    scale=max(float(np.percentile(responses,99)),1e-8)
    response=aux['features'][0].square().mean(1).sqrt().numpy()/scale
    weights=aux['weights'][0].numpy();T=a['x'].shape[-1];t=np.arange(T)*meta['grid_s']/3600
    fig=plt.figure(figsize=(9,8))
    gs=fig.add_gridspec(3,2,width_ratios=[1,.025],height_ratios=[1.1,.8,1],hspace=.50,wspace=.10)
    axes=[fig.add_subplot(gs[0,0])]
    axes += [fig.add_subplot(gs[j,0],sharex=axes[0]) for j in [1,2]]
    cax=fig.add_subplot(gs[1,1])
    w=meta['metadata'][i];C=len(w['electrodes'])
    for c in range(C):
        axes[0].plot(t,np.where(a['mask'][i,c]>0,1000*a['x'][i,c],np.nan),label=w['electrodes'][c])
        axes[2].step(t,weights[c],where='post',label=w['electrodes'][c])
    display=np.ma.masked_where(a['mask'][i,:C]<=0,np.clip(response[:C],0,1))
    cmap=plt.get_cmap('viridis').copy();cmap.set_bad('#dedede')
    image=axes[1].imshow(display,aspect='auto',extent=[0,meta['window_s']/3600,C+.5,.5],vmin=0,vmax=1,cmap=cmap)
    axes[1].set_yticks(np.arange(1,C+1),w['electrodes']);fig.colorbar(image,cax=cax,label='Normalised response')
    axes[0].set_ylabel('Potential (mV)');axes[0].legend(ncol=min(C,4),frameon=False)
    axes[1].set_ylabel('Electrode');axes[2].set_ylabel('Reliability weight');axes[2].set_ylim(0,1)
    axes[2].set_xlabel('Time within window (h)')
    for ax,label in zip(axes,['(a) Electrical recordings','(b) Temporal responses','(c) Reliability weights']):
        ax.text(.5,-.18 if ax is not axes[2] else -.38,label,transform=ax.transAxes,ha='center',va='top',fontsize=11,fontweight='bold')
        ax.spines[['top','right']].set_visible(False)
        ax.set_xlim(0,meta['window_s']/3600)
        if ax is not axes[2]:ax.tick_params(labelbottom=False)
    tag='SYNTHETIC ENGINEERING DEMO' if meta['synthetic'] else 'Held-out recording'
    fig.suptitle(f'{tag} | plant {w["plant_id"]} | P(inoculated)={float(aux["probabilities"][0,1]):.3f}',fontsize=11)
    fig.subplots_adjust(top=.90,bottom=.17,left=.10,right=.90)
    fig.text(.5,.025,'Grey response cells: unavailable observations. Weights change within a window only with availability.',ha='center',fontsize=9)
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    fig.savefig(out/'temporal_explanation.png',dpi=300,bbox_inches='tight');fig.savefig(out/'temporal_explanation.pdf',bbox_inches='tight')
    np.savez_compressed(out/'explanation_arrays.npz',response=response,weights=weights,train_response_scale=scale)
    plt.close(fig)

def robustness(csv,out,synthetic=False):
    df=pd.read_csv(csv,dtype={'plant_id':str,'session_id':str});fig,axes=plt.subplots(1,2,figsize=(10,4),sharey=True);rows=[]
    for kind,ax in zip(['missing','noise'],axes):
        for severity,g in df[df.kind==kind].groupby('severity'):
            scores=[]
            for (_,rep),s in g.groupby(['seed','repetition']):
                # Do not report survivor-only accuracy if any windows have failed.
                failure=1-s.usable.mean()
                if failure:score=np.nan
                else:
                    p=aggregate(s);score=metrics(p.label,p.probability)['accuracy_pct']
                scores.append(score)
            vals=np.asarray(scores);ok=np.isfinite(vals)
            rows.append({'kind':kind,'severity':severity,'mean_accuracy_pct':float(vals[ok].mean()) if ok.any() else np.nan,
                         'std_accuracy_pct':float(vals[ok].std()) if ok.any() else np.nan,
                         'failure_fraction':float(1-g.usable.mean()),'omitted_repetitions':int((~ok).sum())})
        rr=[r for r in rows if r['kind']==kind]
        ax.errorbar([r['severity']*(100 if kind=='missing' else 1) for r in rr],
                    [r['mean_accuracy_pct'] for r in rr],yerr=[r['std_accuracy_pct'] for r in rr],marker='o',capsize=3)
        ax.set_xlabel('Missing observations (%)' if kind=='missing' else 'Noise standard deviation / signal standard deviation')
        ax.set_title('(a) Missing samples' if kind=='missing' else '(b) Electrode noise');ax.grid(alpha=.2)
    axes[0].set_ylabel('Plant classification accuracy (%)')
    fig.suptitle('SYNTHETIC ENGINEERING DEMO' if synthetic else 'Held-out robustness evaluation')
    fig.tight_layout();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(out/'robustness_summary.csv',index=False)
    fig.savefig(out/'robustness.png',dpi=300,bbox_inches='tight');fig.savefig(out/'robustness.pdf',bbox_inches='tight');plt.close(fig)
