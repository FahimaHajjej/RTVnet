"""Audit source ZIPs and export only explicitly reviewed electrode mappings."""
import io,json,zipfile,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import openpyxl

def audit(archive,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);inventory=[];labels=[]
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            if info.is_dir():continue
            raw=z.read(info.filename)
            item={'member':info.filename,'bytes':info.file_size,'sha256':hashlib.sha256(raw).hexdigest()}
            if info.filename.endswith('.xlsx'):
                w=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
                item['sheets']=[]
                for s in w:
                    item['sheets'].append({'sheet':s.title,'rows':s.max_row,'columns':s.max_column})
                    # Export metadata cells only; never silently assign biological plants.
                    if s.max_row<200:
                        for row_number,row in enumerate(s.iter_rows(max_col=6,values_only=False),1):
                            vals=[c.value for c in row]
                            if any(v is not None for v in vals):
                                labels.append({'member':info.filename,'sheet':s.title,'row':row_number,
                                               'first_six_cells':vals})
                w.close()
            inventory.append(item)
    (out/'inventory.json').write_text(json.dumps(inventory,indent=2,default=str))
    (out/'annotation_candidates.json').write_text(json.dumps(labels,indent=2,default=str))
    digest={}
    for i in inventory:digest.setdefault(i['sha256'],[]).append(i['member'])
    (out/'exact_duplicate_files.json').write_text(json.dumps([v for v in digest.values() if len(v)>1],indent=2))
    template={'verified':False,'synthetic':False,'reviewed_by':'','review_notes':'Confirm plants across sessions; cable is not a plant ID.',
              'sources':[{'member':'COPY_EXACT_MEMBER_FROM_INVENTORY.xlsx','sheet':'COPY_SHEET',
                 'format':'annotated_rows','session_id':'REVIEWED_SESSION','time_unit':'seconds',
                 'voltage_unit':'V','time_row':1,'first_value_column':6,'last_value_column':None,
                 'channels':[{'row':3,'plant_id':'REQUIRES_BIOLOGICAL_CONFIRMATION',
                              'electrode_id':'E1','label':0,'substrate':'water'}]}]}
    (out/'mapping_template.json').write_text(json.dumps(template,indent=2))
    return {'files':len(inventory),'annotation_rows':len(labels),'output':str(out)}

def export(archive,mapping,out):
    """Supports annotated Excel rows, raw Excel triplets and tab-separated triplet files.
    All row/column numbers in JSON are 1-based. Labels in JSON already use target convention.
    Choose one nonduplicated measurement representation per session. No inferred IDs.
    """
    spec=json.loads(Path(mapping).read_text())
    if spec.get('verified') is not True or not spec.get('reviewed_by'):
        raise ValueError('Review biological identities, labels, units and duplicates before verified=true')
    records=[]
    with zipfile.ZipFile(archive) as z:
        for source in spec['sources']:
            raw=z.read(source['member']);fmt=source['format'];unit=source.get('time_unit','seconds')
            if unit not in ['seconds','excel_days']:raise ValueError('Explicit seconds/excel_days units required')
            scale=86400 if unit=='excel_days' else 1
            offset=source.get('time_origin_s',0)
            voltage_unit=source.get('voltage_unit')
            if voltage_unit not in ['V','mV']:raise ValueError('Explicit voltage_unit V or mV required')
            voltage_scale=1 if voltage_unit=='V' else .001
            def add(ch,t,v):
                if t is None or v is None:return
                try:t=float(t)*scale+offset;v=float(v)*voltage_scale
                except (TypeError,ValueError):return
                if not np.isfinite(t):return
                records.append({'plant_id':str(ch['plant_id']),'session_id':str(source['session_id']),
                    'electrode_id':str(ch['electrode_id']),'time_s':t,'voltage_v':v,
                    'label':int(ch['label']),'substrate':str(ch['substrate'])})
            if fmt=='annotated_rows':
                w=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True);s=w[source['sheet']]
                start=source['first_value_column'];end=source.get('last_value_column') or s.max_column
                times=next(s.iter_rows(min_row=source['time_row'],max_row=source['time_row'],min_col=start,max_col=end,values_only=True))
                for ch in source['channels']:
                    vs=next(s.iter_rows(min_row=ch['row'],max_row=ch['row'],min_col=start,max_col=end,values_only=True))
                    for t,v in zip(times,vs):add(ch,t,v)
                w.close()
            elif fmt in ['triplet_sheet','triplet_csv']:
                channels={int(ch['channel']):ch for ch in source['channels']}
                if fmt=='triplet_sheet':
                    w=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
                    rows=w[source['sheet']].iter_rows(min_row=source.get('first_row',1),values_only=True)
                else:rows=[line.split() for line in raw.decode('utf-8-sig').splitlines()]
                for row in rows:
                    for j in range(0,len(row)-2,3):
                        try:code=int(row[j])
                        except (TypeError,ValueError):continue
                        if code in channels:add(channels[code],row[j+1],row[j+2])
                if fmt=='triplet_sheet':w.close()
            else:raise ValueError(f'Unsupported format {fmt}')
    if not records:raise ValueError('No numerical measurements exported; review source mapping')
    Path(out).parent.mkdir(parents=True,exist_ok=True)
    d=pd.DataFrame(records);d.to_csv(out,index=False)
    # Provenance travels with the exported CSV, but preparation still verifies row identities.
    Path(str(out)+'.manifest.json').write_text(json.dumps(spec,indent=2))
    return {'measurements':len(d),'plants':d.plant_id.nunique(),'sessions':d.session_id.nunique()}
