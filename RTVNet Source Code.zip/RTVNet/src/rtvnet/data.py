"""STEP-BY-STEP preparation. Units: seconds and volts at the input boundary.
No filename/cable-to-plant inference is made. Source annotations must be reviewed.
"""
from pathlib import Path
import json,os,hashlib
import numpy as np
import pandas as pd

REQUIRED={'plant_id','session_id','electrode_id','time_s','voltage_v','label','substrate'}

def quality_from_mask(mask,dt=240.):
    """Observed fraction, longest missing run / T, dropout intervals per hour."""
    m=np.asarray(mask,bool); t=m.shape[-1]; out=np.zeros((*m.shape[:-1],3),np.float32)
    for idx in np.ndindex(m.shape[:-1]):
        bad=~m[idx]; edges=np.diff(np.r_[False,bad,False].astype(int))
        starts=np.where(edges==1)[0]; ends=np.where(edges==-1)[0]
        out[idx]=[m[idx].mean(),max(ends-starts,default=0)/t,len(starts)/(t*dt/3600)]
    return out

def read_long(path):
    d=pd.read_csv(path,dtype={'plant_id':str,'session_id':str,'electrode_id':str,'substrate':str})
    if d.empty:raise ValueError('Input CSV contains no observations')
    if REQUIRED-set(d): raise ValueError(f'Missing columns: {REQUIRED-set(d)}')
    for k in ['time_s','voltage_v','label']: d[k]=pd.to_numeric(d[k],errors='raise')
    if not np.isfinite(d.time_s).all():raise ValueError('Timestamps must be finite seconds')
    if not d.label.isin([0,1]).all(): raise ValueError('Labels must be 0=healthy, 1=inoculated')
    if d[['plant_id','session_id','electrode_id','substrate']].isna().any().any():raise ValueError('Missing identities')
    if any(d[k].str.strip().eq('').any() for k in ['plant_id','session_id','electrode_id','substrate']):raise ValueError('Identity fields cannot be blank')
    if d.groupby('plant_id').label.nunique().max()>1:raise ValueError('A plant has inconsistent class labels')
    if d.groupby('plant_id').substrate.nunique().max()>1:raise ValueError('A plant has inconsistent substrate labels')
    keys=['plant_id','session_id','electrode_id','time_s']
    if (d.groupby(keys).voltage_v.nunique()>1).any():raise ValueError('Conflicting duplicate voltage records')
    return d.drop_duplicates(keys).sort_values(keys).reset_index(drop=True)

def prepare(long_csv,output,manifest,grid=240.,window=14400.,stride=7200.,max_gap=480.,coverage=.70,min_electrodes=2):
    """1 validate identities; 2 window; 3 align observations and raw derivatives;
    4 calculate quality; 5 pad electrode dimension and save provenance."""
    if not all(np.isfinite(v) and v>0 for v in [grid,window,stride,max_gap]):
        raise ValueError('Grid, window, stride and maximum gap must be finite and positive')
    if not 0<=coverage<=1 or min_electrodes<1:raise ValueError('Invalid coverage or electrode minimum')
    if not np.isclose(stride/grid,round(stride/grid)):raise ValueError('Stride must be a multiple of the grid interval')
    provenance=json.loads(Path(manifest).read_text())
    if provenance.get('verified') is not True:raise ValueError('Reviewed provenance manifest must set verified=true')
    if not provenance.get('synthetic',False) and not provenance.get('reviewed_by'):
        raise ValueError('Real-data manifest requires reviewed_by')
    d=read_long(long_csv); T=int(round(window/grid))
    if T<4 or not np.isclose(T*grid,window):raise ValueError('window must be an integer multiple of grid')
    values=[]; masks=[]; diffs=[]; vms=[]; metadata=[]
    for (plant,session),g in d.groupby(['plant_id','session_id'],sort=True):
        origin=float(g.time_s.min()); stop=float(g.time_s.max())+grid
        for start in np.arange(origin,stop-window+1e-6,stride):
            xs=[];ms=[];vs=[];ds=[];electrodes=[]
            for electrode,e in g.groupby('electrode_id',sort=True):
                # Compute differences on original adjacent samples, not interpolated grid values.
                e=e.sort_values('time_s'); tt=e.time_s.to_numpy(float); yy=e.voltage_v.to_numpy(float)
                valid=np.isfinite(tt)&np.isfinite(yy)
                delta=np.diff(tt); v=np.zeros(len(tt)); vm=np.zeros(len(tt),bool)
                ok=valid[1:]&valid[:-1]&(delta>0)&(delta<=max_gap)
                v[1:][ok]=np.diff(yy)[ok]/delta[ok]*3600 # volts/hour
                vm[1:]=ok
                # Do not use a derivative whose previous observation lies outside this window.
                vm[1:] &= tt[:-1]>=start
                keep=valid&(tt>=start)&(tt<start+window)
                x=np.zeros(T);m=np.zeros(T);dv=np.zeros(T);dm=np.zeros(T)
                # Assign actual observations to nearest grid centres (half-grid tolerance).
                idx=np.floor((tt-start)/grid+.5).astype(int)
                for i in range(T):
                    candidates=np.flatnonzero(keep&(idx==i)&(np.abs(tt-(start+i*grid))<=grid/2))
                    if len(candidates):
                        j=candidates[np.argmin(np.abs(tt[candidates]-(start+i*grid)))]
                        x[i]=yy[j];m[i]=1
                        if vm[j]:dv[i]=v[j];dm[i]=1
                if m.mean()<coverage:continue
                # Fill short interior gaps for export only; masks stay zero and model suppresses them.
                obs=np.flatnonzero(m)
                for left,right in zip(obs[:-1],obs[1:]):
                    if (right-left)*grid<=max_gap:
                        x[left:right+1]=np.linspace(x[left],x[right],right-left+1)
                xs.append(x);ms.append(m);vs.append(dv);ds.append(dm);electrodes.append(str(electrode))
            if len(xs)<min_electrodes:continue
            values.append(np.array(xs));masks.append(np.array(ms));diffs.append(np.array(vs));vms.append(np.array(ds))
            metadata.append({'plant_id':str(plant),'session_id':str(session),'start_s':float(start),
                             'label':int(g.label.iloc[0]),'substrate':str(g.substrate.iloc[0]),'electrodes':electrodes})
    if not values:raise ValueError('No eligible windows; check mapping, units, duration and coverage')
    C=max(x.shape[0] for x in values)
    def pad(items):return np.stack([np.pad(x,((0,C-len(x)),(0,0))) for x in items]).astype(np.float32)
    X,M,V,VM=map(pad,[values,masks,diffs,vms]);Q=quality_from_mask(M,grid)
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    config={'grid_s':grid,'window_s':window,'stride_s':stride,'max_gap_s':max_gap,'coverage':coverage,'min_electrodes':min_electrodes,
            'synthetic':bool(provenance.get('synthetic',False)),'manifest':provenance,
            'source_csv':os.path.relpath(Path(long_csv).resolve(),out.parent.resolve()),'metadata':metadata}
    np.savez_compressed(out,x=X,mask=M,diff=V,diff_mask=VM,quality=Q,
                        y=np.array([m['label'] for m in metadata],np.int64),
                        metadata_json=np.array(json.dumps(config)))
    return config

def load_windows(path):
    with np.load(path,allow_pickle=False) as z:
        a={k:z[k] for k in ['x','mask','diff','diff_mask','quality','y']}
        meta=json.loads(str(z['metadata_json']))
    validate_windows(a,meta)
    return a,meta

def validate_windows(a,meta):
    """Reject malformed arrays before they can invalidate grouping or metrics."""
    provenance=meta.get('manifest',{})
    if provenance.get('verified') is not True:raise ValueError('Prepared data require reviewed provenance')
    if not isinstance(meta.get('synthetic'),bool):raise ValueError('Explicit synthetic provenance flag required')
    if not meta['synthetic'] and not provenance.get('reviewed_by'):raise ValueError('Real data require reviewer identity')
    x=a['x']
    if x.ndim!=3 or min(x.shape)<1 or x.shape[-1]<4:
        raise ValueError('Expected a nonempty N x C x T input with at least four positions')
    for key in ['mask','diff','diff_mask']:
        if a[key].shape!=x.shape:raise ValueError(f'Shape mismatch: {key}')
    if a['quality'].shape!=(*x.shape[:2],3):raise ValueError('Expected three quality indicators per electrode')
    if a['y'].shape!=(len(x),) or not np.isin(a['y'],[0,1]).all():raise ValueError('Invalid class-label array')
    for key in a:
        if not np.isfinite(a[key]).all():raise ValueError(f'Non-finite values in {key}')
    for key in ['mask','diff_mask']:
        if not np.isin(a[key],[0,1]).all():raise ValueError(f'{key} must be binary')
    if np.any(a['diff_mask']>a['mask']):raise ValueError('Variation mask requires an observed sample')
    rows=meta.get('metadata',[])
    if len(rows)!=len(x):raise ValueError('Metadata/window count mismatch')
    if np.any(a['mask'].sum((1,2))==0):raise ValueError('Prepared windows must contain observations')
    seen=set();plant_labels={}
    for i,w in enumerate(rows):
        required={'plant_id','session_id','start_s','label','substrate','electrodes'}
        if required-set(w):raise ValueError('Incomplete window metadata')
        if w['label']!=int(a['y'][i]):raise ValueError('Window metadata label disagrees with label array')
        old=plant_labels.setdefault(w['plant_id'],(w['label'],w['substrate']))
        if old!=(w['label'],w['substrate']):raise ValueError('Inconsistent plant identity metadata')
        key=(w['plant_id'],w['session_id'],w['start_s'])
        if key in seen:raise ValueError('Duplicate prepared window identity')
        seen.add(key)
        c=len(w['electrodes'])
        if not 1<=c<=x.shape[1] or len(set(w['electrodes']))!=c:raise ValueError('Invalid electrode identities')
        if a['mask'][i,c:].any():raise ValueError('Padded electrode channels cannot contain observations')
    for key in ['grid_s','window_s','stride_s','max_gap_s']:
        if not np.isfinite(meta.get(key,0)) or meta.get(key,0)<=0:raise ValueError(f'Invalid {key}')
    if not np.isclose(meta['window_s']/meta['grid_s'],x.shape[-1]):raise ValueError('Window length/grid inconsistent with array')
    expected=quality_from_mask(a['mask'],meta['grid_s'])
    if not np.allclose(expected,a['quality'],rtol=1e-5,atol=1e-6):raise ValueError('Quality descriptors disagree with masks')

def dataset_fingerprint(a,meta):
    """Portable binding of arrays and identities; excludes filesystem paths."""
    h=hashlib.sha256()
    for key in sorted(a):
        v=np.ascontiguousarray(a[key]);h.update(key.encode());h.update(str(v.shape).encode());h.update(str(v.dtype).encode());h.update(v.tobytes())
    stable={k:meta[k] for k in ['grid_s','window_s','stride_s','max_gap_s','coverage','synthetic','metadata']}
    h.update(json.dumps(stable,sort_keys=True,separators=(',',':')).encode())
    return h.hexdigest()

class Scaler:
    """Training partition only: global voltage, derivative, and per-quality-feature scaling."""
    def fit(self,a,idx):
        def stats(v,m):
            z=v[idx][m[idx]>0]
            return (float(z.mean()),max(float(z.std()),1e-8)) if len(z) else (0.,1.)
        self.xmean,self.xstd=stats(a['x'],a['mask'])
        self.vmean,self.vstd=stats(a['diff'],a['diff_mask'])
        good=a['mask'][idx].sum(-1)>0;q=a['quality'][idx][good]
        self.qmean=q.mean(0);self.qstd=np.maximum(q.std(0),1e-6)
        return self
    def transform(self,a):
        return {'x':np.where(a['mask']>0,(a['x']-self.xmean)/self.xstd,0).astype(np.float32),
                'mask':a['mask'].astype(np.float32),
                'diff':np.where(a['diff_mask']>0,(a['diff']-self.vmean)/self.vstd,0).astype(np.float32),
                'diff_mask':a['diff_mask'].astype(np.float32),
                'quality':((a['quality']-self.qmean)/self.qstd).astype(np.float32),'y':a['y']}
    def as_dict(self):return {k:np.asarray(v).tolist() for k,v in vars(self).items()}
    @classmethod
    def from_dict(cls,d):
        s=cls()
        for k,v in d.items():setattr(s,k,np.array(v) if k.startswith('q') else float(v))
        return s
