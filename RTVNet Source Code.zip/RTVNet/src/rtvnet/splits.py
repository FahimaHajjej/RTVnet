"""Plant-level outer leave-one-out / deterministic inner holdout; fail closed."""
import numpy as np

def make_splits(metadata,seed=11):
    plants={}
    for m in metadata:
        p=m['plant_id']; value=(int(m['label']),m['substrate'])
        if p in plants and plants[p]!=value:raise ValueError('Inconsistent plant metadata')
        plants[p]=value
    for cls in (0,1):
        if sum(v[0]==cls for v in plants.values())<3:
            raise ValueError('Need at least three VERIFIED plants per class for this nested protocol')
    out=[]
    for test in sorted(plants):
        rng=np.random.default_rng(seed); chosen=[]
        for cls in (0,1):
            eligible=[p for p in sorted(plants) if p!=test and plants[p][0]==cls]
            rng.shuffle(eligible)
            # Prefer validation substrate matching test; leave remaining plants for training.
            eligible.sort(key=lambda p:plants[p][1]!=plants[test][1])
            chosen.append(eligible[0])
        val=set(chosen);train=set(plants)-val-{test}
        def indices(ps):return np.array([i for i,m in enumerate(metadata) if m['plant_id'] in ps],int)
        assert not train&val and test not in train|val
        out.append({'fold':len(out),'train':indices(train),'val':indices(val),'test':indices({test}),
                    'train_plants':sorted(train),'val_plants':sorted(val),'test_plants':[test]})
    return out
