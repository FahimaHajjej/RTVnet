"""Command line interface. Run `python -m rtvnet --help` for all steps."""
import argparse,json
from pathlib import Path
from . import __version__

def main():
    p=argparse.ArgumentParser(description='RTV-Net: reviewed data -> grouped training -> measured outputs')
    p.add_argument('--version',action='version',version='RTV-Net '+__version__)
    sub=p.add_subparsers(dest='command',required=True)
    s=sub.add_parser('audit');s.add_argument('--archive',required=True);s.add_argument('--out',required=True)
    s=sub.add_parser('export');s.add_argument('--archive',required=True);s.add_argument('--mapping',required=True);s.add_argument('--out',required=True)
    s=sub.add_parser('demo');s.add_argument('--out',default='data/demo');s.add_argument('--plants-per-class',type=int,default=3)
    s=sub.add_parser('prepare');s.add_argument('--csv',required=True);s.add_argument('--manifest',required=True);s.add_argument('--out',required=True)
    s.add_argument('--grid',type=float,default=240);s.add_argument('--window',type=float,default=14400)
    s.add_argument('--stride',type=float,default=7200);s.add_argument('--max-gap',type=float,default=480)
    s.add_argument('--coverage',type=float,default=.70);s.add_argument('--min-electrodes',type=int,default=2)
    for cmd in ['train','ablate']:
        s=sub.add_parser(cmd);s.add_argument('--data',required=True);s.add_argument('--out',required=True)
        s.add_argument('--variant',choices=['rtvnet','backbone','tvem_only','erfm_only'],default='rtvnet')
        s.add_argument('--seeds',type=int,nargs='+',default=[11,22,33,44,55]);s.add_argument('--epochs',type=int,default=200)
        s.add_argument('--batch-size',type=int,default=16);s.add_argument('--patience',type=int,default=25)
        s.add_argument('--device',default='cpu');s.add_argument('--threads',type=int,default=1)
        s.add_argument('--max-folds',type=int);s.add_argument('--width',type=int,default=16)
        s.add_argument('--overwrite',action='store_true',help='Replace an existing RTV-Net training run')
        s.add_argument('--branch-width',type=int,default=8);s.add_argument('--hidden',type=int,default=8)
    for cmd in ['infer','explain','benchmark']:
        s=sub.add_parser(cmd);s.add_argument('--data',required=True);s.add_argument('--checkpoint',required=True);s.add_argument('--out',required=True)
        if cmd=='explain':s.add_argument('--window-index',type=int)
        if cmd=='benchmark':
            s.add_argument('--repeats',type=int,default=1000);s.add_argument('--warmup',type=int,default=100)
    s=sub.add_parser('robustness');s.add_argument('--data',required=True);s.add_argument('--run',required=True)
    s.add_argument('--out',required=True);s.add_argument('--repeats',type=int,default=20);s.add_argument('--raw-csv')
    s=sub.add_parser('report');s.add_argument('--runs',required=True);s.add_argument('--out',required=True)
    args=p.parse_args();a=vars(args).copy();cmd=a.pop('command')
    if cmd=='audit':
        from .adapters import audit
        print(audit(a['archive'],a['out']))
    elif cmd=='export':
        from .adapters import export
        print(export(a['archive'],a['mapping'],a['out']))
    elif cmd=='demo':
        from .demo import demo
        print(demo(a['out'],a['plants_per_class']))
    elif cmd=='prepare':
        from .data import prepare
        result=prepare(a['csv'],a['out'],a['manifest'],grid=a['grid'],window=a['window'],stride=a['stride'],max_gap=a['max_gap'],coverage=a['coverage'],min_electrodes=a['min_electrodes']);print('Eligible windows:',len(result['metadata']))
    elif cmd in ['train','ablate']:
        from .engine import train
        data=a.pop('data');out=a.pop('out')
        if cmd=='train':train(data,out,**a)
        else:
            from .model import VARIANTS
            a.pop('variant')
            for variant in VARIANTS:train(data,str(Path(out)/variant),variant=variant,**a)
    elif cmd=='infer':
        from .engine import infer
        infer(a['data'],a['checkpoint'],a['out'])
    elif cmd=='explain':
        from .plots import explain
        explain(a['data'],a['checkpoint'],a['out'],a['window_index'])
    elif cmd=='benchmark':
        from .engine import benchmark
        print(benchmark(a['data'],a['checkpoint'],a['out'],a['repeats'],a['warmup']))
    elif cmd=='robustness':
        from .robustness import run
        from .plots import robustness
        from .data import load_windows
        run(a['data'],a['run'],a['out'],a['repeats'],a['raw_csv'])
        _,meta=load_windows(a['data']);robustness(str(Path(a['out'])/'robustness_predictions.csv'),a['out'],meta['synthetic'])
    elif cmd=='report':
        import pandas as pd
        rows=[]
        for path in sorted(Path(a['runs']).rglob('summary.json')):
            d=json.loads(path.read_text());rows.append({'run':str(path.parent),
             'synthetic':d['synthetic'],'complete_outer_cv':d['complete_outer_cv'],**d['mean_plant_metrics']})
        if not rows:raise ValueError('No measured summaries found')
        Path(a['out']).parent.mkdir(parents=True,exist_ok=True);pd.DataFrame(rows).to_csv(a['out'],index=False)
if __name__=='__main__':main()
