"""Synthetic engineering fixture: NOT disease evidence, NOT a public dataset export."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .data import prepare

def demo(out,plants_per_class=3,seed=42):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(seed);rows=[]
    for label in (0,1):
        for p in range(plants_per_class):
            plant=f'DEMO_{label}_{p}';session=f'{plant}_S1'
            for c in range(3):
                t=np.arange(0,12*3600,240)+c*12
                voltage=.008*np.sin(2*np.pi*t/86400+c*.3)+rng.normal(0,.001,len(t))
                voltage+=label*.005*(t/(12*3600))+.002*c+rng.normal(0,.001)
                keep=rng.random(len(t))>.03
                for tt,v in zip(t[keep],voltage[keep]):
                    rows.append([plant,session,f'E{c+1}',tt,v,label,'water' if p%2==0 else 'peat'])
    d=pd.DataFrame(rows,columns=['plant_id','session_id','electrode_id','time_s','voltage_v','label','substrate'])
    csv=out/'synthetic_long.csv';d.to_csv(csv,index=False)
    manifest=out/'manifest.json';manifest.write_text(json.dumps({'verified':True,'synthetic':True,
                  'reviewed_by':'synthetic fixture generator','note':'Engineering test only; no experimental observations.'},indent=2))
    prepare(csv,out/'windows.npz',manifest)
    return str(out/'windows.npz')
