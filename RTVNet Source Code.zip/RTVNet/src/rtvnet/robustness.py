"""Perturb ORIGINAL observations and recompute derivatives/masks before prediction.
No manuscript placeholder values are used. Export per-window predictions and failures.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from .data import load_windows,read_long,quality_from_mask
from .engine import load_checkpoint,batch,require_checkpoint_dataset

def rebuild(raw,window,config,C,kind='missing',severity=0.,rng=None):
    rng=np.random.default_rng(0) if rng is None else rng
    dt=config['grid_s'];start=window['start_s'];end=start+config['window_s'];T=round(config['window_s']/dt)
    electrodes=window['electrodes'];x=np.zeros((C,T));m=np.zeros_like(x);v=np.zeros_like(x);vm=np.zeros_like(x)
    chosen=int(rng.integers(len(electrodes))) if kind=='noise' else -1
    for c,electrode in enumerate(electrodes):
        e=raw[(raw.electrode_id==electrode)&(raw.time_s>=start)&(raw.time_s<end)].sort_values('time_s')
        tt=e.time_s.to_numpy(float);yy=e.voltage_v.to_numpy(float).copy()
        if kind=='missing':yy[rng.random(len(yy))<severity]=np.nan
        elif kind=='noise' and c==chosen:
            good=np.isfinite(yy);yy[good]+=rng.normal(0,severity*np.std(yy[good]),good.sum())
        valid=np.isfinite(yy); delta=np.diff(tt);dv=np.zeros(len(tt));dm=np.zeros(len(tt),bool)
        ok=valid[1:]&valid[:-1]&(delta>0)&(delta<=config['max_gap_s'])
        dv[1:][ok]=np.diff(yy)[ok]/delta[ok]*3600;dm[1:]=ok
        bins=np.floor((tt-start)/dt+.5).astype(int)
        for i in range(T):
            cand=np.flatnonzero(valid&(bins==i)&(np.abs(tt-(start+i*dt))<=dt/2))
            if len(cand):
                j=cand[np.argmin(np.abs(tt[cand]-(start+i*dt)))]
                x[c,i]=yy[j];m[c,i]=1
                if dm[j]:v[c,i]=dv[j];vm[c,i]=1
        obs=np.flatnonzero(m[c])
        for left,right in zip(obs[:-1],obs[1:]):
            if (right-left)*dt<=config['max_gap_s']:x[c,left:right+1]=np.linspace(x[c,left],x[c,right],right-left+1)
    return {'x':x[None].astype('float32'),'mask':m[None].astype('float32'),
            'diff':v[None].astype('float32'),'diff_mask':vm[None].astype('float32'),
            'quality':quality_from_mask(m[None],dt),'y':np.array([window['label']])}

def run(path,run_dir,out,repeats=20,raw_csv=None):
    if repeats<1:raise ValueError('Robustness repetitions must be positive')
    a,meta=load_windows(path);source=Path(raw_csv) if raw_csv else Path(meta['source_csv']);source=source if source.is_absolute() else Path(path).resolve().parent/source;raw=read_long(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    records=[];checkpoints=sorted(Path(run_dir).glob('seed_*/fold_*/best.pt'))
    if not checkpoints:raise ValueError('No grouped checkpoints found')
    for checkpoint in checkpoints:
        model,scaler,cp=load_checkpoint(checkpoint)
        require_checkpoint_dataset(cp,a,meta)
        for i,w in enumerate(meta['metadata']):
            if w['plant_id'] not in cp['test_plants']:continue
            group=raw[(raw.plant_id==w['plant_id'])&(raw.session_id==w['session_id'])]
            # Verify exact correspondence before introducing any disturbances.
            clean=rebuild(group,w,meta,a['x'].shape[1],severity=0)
            for key in ['x','mask','diff','diff_mask','quality']:
                if not np.allclose(clean[key][0],a[key][i],rtol=1e-4,atol=1e-7):
                    raise ValueError(f'Clean reconstruction mismatch: {key}; check source data/config')
            for kind,levels in [('missing',[0,.05,.1,.2,.3,.4]),('noise',[0,.25,.5,1,1.5,2])]:
                for level in levels:
                    for rep in range(repeats):
                        # Stable seeds across model variants. Unique perturbations per window/repetition.
                        rng=np.random.default_rng(np.random.SeedSequence([cp['seed'],i,rep,0 if kind=='missing' else 1]))
                        b=rebuild(group,w,meta,a['x'].shape[1],kind,level,rng)
                        with torch.no_grad():aux=model(*batch(scaler.transform(b),[0],'cpu'),return_aux=True)
                        usable=bool(aux['valid_window'][0]);prob=float(aux['probabilities'][0,1]) if usable else np.nan
                        records.append({'seed':cp['seed'],'fold':cp['fold'],'plant_id':w['plant_id'],
                            'session_id':w['session_id'],'label':w['label'],'window_index':i,
                            'kind':kind,'severity':level,'repetition':rep,'probability':prob,'usable':usable})
    df=pd.DataFrame(records);df.to_csv(out/'robustness_predictions.csv',index=False)
    (out/'protocol.json').write_text(json.dumps({'synthetic':meta['synthetic'],'repetitions':repeats,
        'perturbation_stage':'Original observations, before differentiation/alignment',
        'failed_windows':'NaN probability; separately counted, never silently discarded'},indent=2))
    return len(df)
