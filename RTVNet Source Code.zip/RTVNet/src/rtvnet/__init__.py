"""RTV-Net: proposed architecture and reproducible evaluation tools."""
__version__ = "0.2.1"
