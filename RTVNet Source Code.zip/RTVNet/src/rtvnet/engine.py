"""Training, prediction, plant aggregation, honest metrics and CPU benchmarking."""
from pathlib import Path
import json,random,time,platform,sys,shutil
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader,WeightedRandomSampler
from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score,confusion_matrix
from .model import build_model
from . import __version__
from .data import load_windows,Scaler,dataset_fingerprint
from .splits import make_splits

KEYS=['x','mask','diff','diff_mask','quality']
def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True,warn_only=True)

def batch(a,idx,device):return [torch.as_tensor(a[k][idx],dtype=torch.float32,device=device) for k in KEYS]

def predict(model,a,idx,device='cpu',batch_size=64,return_valid=False):
    model.eval();parts=[];valid=[]
    with torch.no_grad():
        for start in range(0,len(idx),batch_size):
            aux=model(*batch(a,idx[start:start+batch_size],device),return_aux=True)
            parts.extend(aux['probabilities'][:,1].cpu().numpy().tolist())
            valid.extend(aux['valid_window'].cpu().numpy().tolist())
    return (np.array(parts),np.array(valid,bool)) if return_valid else np.array(parts)

def metrics(y,p):
    p=np.asarray(p,float);y=np.asarray(y)
    if y.ndim!=1 or p.shape!=y.shape or not len(y):raise ValueError('Metric inputs must be matching nonempty vectors')
    if not np.isin(y,[0,1]).all() or not np.isfinite(p).all() or np.any((p<0)|(p>1)):
        raise ValueError('Metrics require binary labels and finite probabilities in [0,1]')
    yp=p>=.5
    tn,fp,fn,tp=confusion_matrix(y,yp,labels=[0,1]).ravel()
    return {'accuracy_pct':100*accuracy_score(y,yp),'balanced_accuracy_pct':100*balanced_accuracy_score(y,yp) if len(np.unique(y))==2 else None,
            'macro_f1_pct':100*f1_score(y,yp,labels=[0,1],average='macro',zero_division=0),
            'sensitivity_pct':100*tp/(tp+fn) if tp+fn else None,
            'specificity_pct':100*tn/(tn+fp) if tn+fp else None}

def aggregate(df):
    """Window -> session -> plant, equal session weighting; never pool seeds first."""
    if df.empty or df.probability.isna().any():raise ValueError('Cannot aggregate empty or failed predictions')
    if df.groupby('plant_id').label.nunique().max()>1:raise ValueError('Inconsistent plant labels')
    session=df.groupby(['plant_id','session_id','label'],as_index=False).probability.mean()
    return session.groupby(['plant_id','label'],as_index=False).probability.mean()

def bootstrap(plants,n=2000,seed=11):
    rng=np.random.default_rng(seed);groups=[plants[plants.label==k] for k in (0,1)]
    samples=[]
    for _ in range(n):
        d=pd.concat([g.iloc[rng.integers(0,len(g),len(g))] for g in groups])
        samples.append(metrics(d.label,d.probability))
    return {k:np.percentile([v[k] for v in samples],[2.5,97.5]).tolist() for k in samples[0]}

def environment():
    return {'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,
            'processor':platform.processor(),'platform':platform.platform(),
            'cpu_threads':torch.get_num_threads()}

def train(path,out,variant='rtvnet',seeds=(11,22,33,44,55),epochs=200,batch_size=16,
          patience=25,device='cpu',width=16,branch_width=8,hidden=8,max_folds=None,threads=1,overwrite=False):
    # STEP 1. Load identity-verified windows and fix partitions independent of method/seed.
    if min(epochs,batch_size,patience,threads,width,branch_width,hidden)<1:raise ValueError('Training budgets and dimensions must be positive')
    if not seeds or len(set(seeds))!=len(seeds) or min(seeds)<0:raise ValueError('Use distinct nonnegative seeds')
    if max_folds is not None and max_folds<1:raise ValueError('max_folds must be positive')
    torch.set_num_threads(threads); a,meta=load_windows(path); out=Path(out)
    fingerprint=dataset_fingerprint(a,meta)
    if out.exists() and any(out.iterdir()):
        if not overwrite:raise FileExistsError('Output is not empty; choose a fresh run directory or --overwrite')
        if not (out/'run_config.json').is_file():raise ValueError('Refusing overwrite: directory is not a recognised training run')
        for child in out.glob('seed_*'):
            if child.is_dir():shutil.rmtree(child)
        for name in ['summary.json','window_predictions.csv','benchmark.json','summary.csv','results.csv']:
            (out/name).unlink(missing_ok=True)
        for child in out.glob('plants_seed_*.csv'):child.unlink()
        for name in ['robustness','explanation']:
            child=out/name
            if child.is_dir():shutil.rmtree(child)
    out.mkdir(parents=True,exist_ok=True)
    splits=make_splits(meta['metadata']);splits=splits if max_folds is None else splits[:max_folds]
    complete=len(splits)==len(set(m['plant_id'] for m in meta['metadata']))
    kwargs={'width':width,'branch_width':branch_width,'hidden':hidden}
    settings={'dataset_fingerprint':fingerprint,'implementation_version':__version__,'dataset':str(Path(path).resolve()),'synthetic':meta['synthetic'],'variant':variant,
              'model_kwargs':kwargs,'epochs':epochs,'seeds':list(seeds),'complete_outer_cv':complete,
              'environment':environment(),'threshold':.5,'batch_size':batch_size,'patience':patience}
    (out/'run_config.json').write_text(json.dumps(settings,indent=2))
    (out/'splits.json').write_text(json.dumps([{k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in s.items()} for s in splits],indent=2))
    records=[];seed_summaries=[]
    for seed in seeds:
        seed_records=[]
        for split in splits:
            seed_all(int(seed));tr,va,te=(split[k] for k in ['train','val','test'])
            # STEP 2. Fit all scaling exclusively on outer-training, not validation/test plants.
            scaler=Scaler().fit(a,tr);scaled=scaler.transform(a)
            model=build_model(variant,**kwargs).to(device)
            optimiser=torch.optim.Adam(model.parameters(),lr=1e-3)
            scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(optimiser,factor=.5,patience=10,min_lr=1e-5)
            ids=[meta['metadata'][i]['plant_id'] for i in tr]
            counts={p:ids.count(p) for p in set(ids)}
            weights=torch.tensor([1/counts[p] for p in ids],dtype=torch.double)
            sampler=WeightedRandomSampler(weights,len(tr),replacement=True,generator=torch.Generator().manual_seed(int(seed)))
            folder=out/f'seed_{seed}'/f'fold_{split["fold"]}';folder.mkdir(parents=True,exist_ok=True)
            best=float('inf');bad=0;history=[]
            for epoch in range(epochs):
                model.train();losses=[]
                # STEP 3. Balance plant contribution; keep windows grouped in every split.
                for local in DataLoader(list(range(len(tr))),batch_size=batch_size,sampler=sampler):
                    ix=tr[local.numpy()]; optimiser.zero_grad()
                    prob=model(*batch(scaled,ix,device))
                    y=torch.as_tensor(a['y'][ix],device=device)
                    loss=torch.nn.functional.nll_loss(prob.clamp_min(1e-8).log(),y)
                    loss.backward();optimiser.step();losses.append(float(loss.detach()))
                # Plant-balanced validation loss, without using test labels.
                pv=predict(model,scaled,va,device); val=[]
                for p in split['val_plants']:
                    ii=[j for j,i in enumerate(va) if meta['metadata'][i]['plant_id']==p]
                    yy=a['y'][va[ii]];pp=np.clip(pv[ii],1e-8,1-1e-8)
                    val.append(float(-(yy*np.log(pp)+(1-yy)*np.log(1-pp)).mean()))
                vl=float(np.mean(val));scheduler.step(vl)
                history.append({'epoch':epoch+1,'train_loss':float(np.mean(losses)),'val_loss':vl})
                if vl<best-1e-8:
                    best=vl;bad=0
                    torch.save({'state_dict':model.state_dict(),'variant':variant,'model_kwargs':kwargs,
                                'scaler':scaler.as_dict(),'train_plants':split['train_plants'],
                                'val_plants':split['val_plants'],'test_plants':split['test_plants'],
                                'synthetic':meta['synthetic'],'seed':int(seed),'fold':split['fold'],
                                'dataset_fingerprint':fingerprint,'preprocessing':{k:meta[k] for k in ['grid_s','window_s','max_gap_s']},
                                'parameter_count':sum(p.numel() for p in model.parameters() if p.requires_grad)},folder/'best.pt')
                else:bad+=1
                if bad>=patience:break
            pd.DataFrame(history).to_csv(folder/'history.csv',index=False)
            # STEP 4. Restore validation-selected weights; test exactly once after selection.
            cp=torch.load(folder/'best.pt',map_location=device,weights_only=True)
            model.load_state_dict(cp['state_dict']);pp=predict(model,scaled,te,device)
            for i,p in zip(te,pp):
                row={k:meta['metadata'][i][k] for k in ['plant_id','session_id','label','start_s']}
                row.update({'window_index':int(i),'probability':float(p),'seed':int(seed),'fold':split['fold']})
                seed_records.append(row);records.append(row)
            print(f'{variant} seed={seed} fold={split["fold"]} epochs={len(history)} parameters={cp["parameter_count"]}',flush=True)
        plants=aggregate(pd.DataFrame(seed_records));plants.to_csv(out/f'plants_seed_{seed}.csv',index=False)
        entry={'seed':int(seed),'plant_metrics':metrics(plants.label,plants.probability)}
        if complete:entry['plant_bootstrap_95ci']=bootstrap(plants)
        seed_summaries.append(entry)
    pd.DataFrame(records).to_csv(out/'window_predictions.csv',index=False)
    summary={'synthetic':meta['synthetic'],'complete_outer_cv':complete,'per_seed':seed_summaries,
             'mean_plant_metrics':{k:(float(np.mean(v)) if (v:=[s['plant_metrics'][k] for s in seed_summaries if s['plant_metrics'][k] is not None]) else None) for k in seed_summaries[0]['plant_metrics']}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2));return summary

def load_checkpoint(path,device='cpu'):
    cp=torch.load(path,map_location=device,weights_only=True)
    model=build_model(cp['variant'],**cp['model_kwargs']).to(device)
    model.load_state_dict(cp['state_dict']);model.eval()
    return model,Scaler.from_dict(cp['scaler']),cp

def infer(path,checkpoint,out):
    a,meta=load_windows(path);model,scaler,cp=load_checkpoint(checkpoint)
    for key,value in cp.get('preprocessing',{}).items():
        if not np.isclose(meta[key],value):raise ValueError(f'Checkpoint preprocessing mismatch: {key}')
    p,valid=predict(model,scaler.transform(a),np.arange(len(a['y'])),return_valid=True)
    df=pd.DataFrame(meta['metadata']);df['usable']=valid
    df['probability']=np.where(valid,p,np.nan);df['prediction']=pd.array([int(v>=.5) if ok else pd.NA for v,ok in zip(p,valid)],dtype='Int64')
    # Inference on arbitrary data is not an independent test claim.
    Path(out).parent.mkdir(parents=True,exist_ok=True);df.to_csv(out,index=False)

def benchmark(path,checkpoint,out,repeats=1000,warmup=100):
    if repeats<1 or warmup<0:raise ValueError('repeats must be positive and warmup nonnegative')
    torch.set_num_threads(1);a,meta=load_windows(path);model,scaler,cp=load_checkpoint(checkpoint)
    for key,value in cp.get('preprocessing',{}).items():
        if not np.isclose(meta[key],value):raise ValueError(f'Checkpoint preprocessing mismatch: {key}')
    # Includes training-fitted scaling, tensor conversion, feature pipeline and aggregation.
    one={k:v[:1] for k,v in a.items()}; times=[]
    with torch.no_grad():
        for i in range(warmup+repeats):
            start=time.perf_counter();sc=scaler.transform(one);model(*batch(sc,[0],'cpu'))
            elapsed=(time.perf_counter()-start)*1000
            if i>=warmup:times.append(elapsed)
    result={'trainable_parameters':cp['parameter_count'],'median_ms_per_window':float(np.median(times)),
            'input_shape':list(one['x'].shape),'repeats':repeats,'warmup':warmup,
            'environment':environment(),'synthetic':meta['synthetic'],
            'scope':'Prepared-window scaling, tensor conversion and complete model; excludes raw parsing, resampling and original-timestamp differentiation.'}
    Path(out).parent.mkdir(parents=True,exist_ok=True);Path(out).write_text(json.dumps(result,indent=2));return result


def require_checkpoint_dataset(cp,a,meta):
    expected=cp.get('dataset_fingerprint')
    if not expected:raise ValueError('Checkpoint lacks a dataset binding; retrain using version 0.2 before evaluation/explanation')
    if dataset_fingerprint(a,meta)!=expected:raise ValueError('Dataset does not match checkpoint: arrays, identities or preprocessing changed')
