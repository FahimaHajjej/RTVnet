"""Regression checks for the 0.2 data-integrity and run-isolation fixes."""
import unittest,tempfile,json
from pathlib import Path
import numpy as np
from rtvnet.data import load_windows,validate_windows,dataset_fingerprint,prepare
from rtvnet.demo import demo
from rtvnet.engine import require_checkpoint_dataset,train,metrics

class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.path=demo(self.root);self.a,self.meta=load_windows(self.path)
    def tearDown(self):self.temp.cleanup()
    def test_checkpoint_binding_detects_value_changes(self):
        cp={'dataset_fingerprint':dataset_fingerprint(self.a,self.meta)}
        require_checkpoint_dataset(cp,self.a,self.meta)
        self.a['x'][0,0,0]+=.001
        with self.assertRaisesRegex(ValueError,'does not match'):require_checkpoint_dataset(cp,self.a,self.meta)
    def test_binding_is_portable_but_identity_sensitive(self):
        original=dataset_fingerprint(self.a,self.meta)
        self.meta['source_csv']='/a/different/location.csv'
        self.assertEqual(original,dataset_fingerprint(self.a,self.meta))
        self.meta['metadata'][0]['plant_id']='changed'
        self.assertNotEqual(original,dataset_fingerprint(self.a,self.meta))
    def test_invalid_label_alignment_rejected(self):
        self.a['y'][0]=1-self.a['y'][0]
        with self.assertRaisesRegex(ValueError,'disagrees'):validate_windows(self.a,self.meta)
    def test_quality_and_masks_must_agree(self):
        self.a['quality'][0,0,0]=0
        with self.assertRaisesRegex(ValueError,'Quality'):validate_windows(self.a,self.meta)
    def test_unreviewed_provenance_rejected(self):
        self.meta['manifest']['verified']=False
        with self.assertRaisesRegex(ValueError,'provenance'):validate_windows(self.a,self.meta)
    def test_nan_metric_input_rejected(self):
        with self.assertRaises(ValueError):metrics([0,1],[.2,np.nan])
    def test_invalid_preparation_settings_rejected(self):
        with self.assertRaises(ValueError):prepare(self.root/'synthetic_long.csv',self.root/'bad.npz',self.root/'manifest.json',grid=0)
    def test_invalid_training_budget_rejected(self):
        with self.assertRaises(ValueError):train(self.path,self.root/'out',epochs=0,seeds=[11])
    def test_existing_run_not_reused_silently(self):
        out=self.root/'run';out.mkdir();(out/'keep.txt').write_text('keep')
        with self.assertRaises(FileExistsError):train(self.path,out,epochs=1,seeds=[11],max_folds=1)
        self.assertEqual((out/'keep.txt').read_text(),'keep')
    def test_unknown_directory_not_overwritten(self):
        out=self.root/'run';out.mkdir();(out/'keep.txt').write_text('keep')
        with self.assertRaises(ValueError):train(self.path,out,epochs=1,seeds=[11],max_folds=1,overwrite=True)

if __name__=='__main__':unittest.main()
