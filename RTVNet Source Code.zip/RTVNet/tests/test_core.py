"""Meaningful invariants: masks, electrode symmetry, frozen filters, split leakage,
original-time derivatives and equivalence of robustness reconstruction."""
import unittest,tempfile,json
from pathlib import Path
import numpy as np
import torch
from rtvnet.model import build_model
from rtvnet.data import load_windows,Scaler,quality_from_mask,read_long
from rtvnet.demo import demo
from rtvnet.splits import make_splits
from rtvnet.robustness import rebuild

torch.set_num_threads(1)
class ModelTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(1);self.model=build_model().eval()
        self.x=torch.randn(2,3,60);self.m=torch.ones_like(self.x);self.d=torch.randn_like(self.x)
        self.q=torch.zeros(2,3,3)
    def test_weights_normalise_and_mask(self):
        self.m[:,1,10:20]=0
        with torch.no_grad():a=self.model(self.x,self.m,self.d,self.m,self.q,True)
        self.assertTrue(torch.all(a['weights'][:,1,10:20]==0))
        torch.testing.assert_close(a['weights'].sum(1),torch.ones(2,60))
    def test_missing_values_do_not_affect_output(self):
        self.m[:,1]=0;x2=self.x.clone();x2[:,1]=1e6;d2=self.d.clone();d2[:,1]=-1e6
        with torch.no_grad():
            a=self.model(self.x,self.m,self.d,self.m,self.q)
            b=self.model(x2,self.m,d2,self.m,self.q)
        torch.testing.assert_close(a,b)
    def test_electrode_permutation_invariance(self):
        perm=[2,0,1]
        with torch.no_grad():
            a=self.model(self.x,self.m,self.d,self.m,self.q)
            b=self.model(self.x[:,perm],self.m[:,perm],self.d[:,perm],self.m[:,perm],self.q[:,perm])
        torch.testing.assert_close(a,b)
    def test_all_missing_is_explicit_failure(self):
        m=torch.zeros_like(self.m)
        with torch.no_grad():a=self.model(self.x,m,self.d,m,self.q,True)
        self.assertFalse(a['valid_window'].any())
        self.assertTrue(torch.isfinite(a['probabilities']).all())
        self.assertEqual(float(a['weights'].sum()),0)
    def test_backward_and_frozen_patterns(self):
        self.model.train();before={k:v.clone() for k,v in self.model.backbone.fixed.named_buffers()}
        loss=-self.model(self.x,self.m,self.d,self.m,self.q)[:,1].log().mean();loss.backward()
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in self.model.parameters() if p.grad is not None))
        for k,v in self.model.backbone.fixed.named_buffers():torch.testing.assert_close(v,before[k])
    def test_all_ablations_run(self):
        for variant in ['backbone','tvem_only','erfm_only','rtvnet']:
            model=build_model(variant).eval()
            with torch.no_grad():p=model(self.x,self.m,self.d,self.m,self.q)
            torch.testing.assert_close(p.sum(1),torch.ones(2))

class DataTests(unittest.TestCase):
    def test_demo_splits_scaling_and_rebuild(self):
        with tempfile.TemporaryDirectory() as td:
            path=demo(td);a,meta=load_windows(path);splits=make_splits(meta['metadata'])
            self.assertEqual(len(splits),6)
            for s in splits:
                self.assertFalse(set(s['train_plants'])&set(s['test_plants']))
                self.assertFalse(set(s['train_plants'])&set(s['val_plants']))
            s=splits[0];sc=Scaler().fit(a,s['train']);original=sc.xmean
            changed={k:v.copy() for k,v in a.items()};changed['x'][s['test']]+=1e6
            self.assertEqual(Scaler().fit(changed,s['train']).xmean,original)
            raw=read_long(Path(path).parent/meta['source_csv']);w=meta['metadata'][0]
            g=raw[(raw.plant_id==w['plant_id'])&(raw.session_id==w['session_id'])]
            clean=rebuild(g,w,meta,a['x'].shape[1],severity=0)
            for k in ['x','mask','diff','diff_mask','quality']:
                np.testing.assert_allclose(clean[k][0],a[k][0],rtol=1e-5,atol=1e-7)
            bad=rebuild(g,w,meta,a['x'].shape[1],severity=1)
            self.assertEqual(float(bad['mask'].sum()),0)
            self.assertEqual(float(bad['diff_mask'].sum()),0)
    def test_quality_descriptors(self):
        m=np.array([[[1,0,0,1]]]);q=quality_from_mask(m,900)
        np.testing.assert_allclose(q[0,0],[.5,.5,1])
if __name__=='__main__':unittest.main()
