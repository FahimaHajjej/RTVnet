import unittest,tempfile,zipfile,io,json
from pathlib import Path
import openpyxl
import numpy as np
from rtvnet.adapters import audit,export
from rtvnet.data import read_long
from rtvnet.engine import metrics

class AdapterTests(unittest.TestCase):
    def test_review_gate_and_time_voltage_units(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);w=openpyxl.Workbook();s=w.active;s.title='data'
            s.append(['time',None,None,None,None,0,1/24,2/24])
            s.append([None]*8);s.append([1,1,None,1,1,10,20,30])
            b=io.BytesIO();w.save(b)
            archive=p/'source.zip'
            with zipfile.ZipFile(archive,'w') as z:z.writestr('test.xlsx',b.getvalue())
            audit(archive,p/'audit')
            spec={'verified':False,'reviewed_by':'unit test','sources':[
                {'member':'test.xlsx','sheet':'data','format':'annotated_rows','session_id':'S',
                 'time_unit':'excel_days','voltage_unit':'mV','time_row':1,'first_value_column':6,
                 'channels':[{'row':3,'plant_id':'P','electrode_id':'E','label':0,'substrate':'water'}]}]}
            mapping=p/'map.json';mapping.write_text(json.dumps(spec))
            with self.assertRaises(ValueError):export(archive,mapping,p/'out.csv')
            spec['verified']=True;mapping.write_text(json.dumps(spec));export(archive,mapping,p/'out.csv')
            d=read_long(p/'out.csv')
            np.testing.assert_allclose(d.time_s,[0,3600,7200]);np.testing.assert_allclose(d.voltage_v,[.01,.02,.03])
    def test_single_class_metrics_are_not_balanced_estimates(self):
        d=metrics([0,0],[.1,.2]);self.assertIsNone(d['balanced_accuracy_pct']);self.assertIsNone(d['sensitivity_pct'])

if __name__=='__main__':unittest.main()
