#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
# Run from the RTVNet project root. Internet is required for initial installation.
python3 -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/python scripts/quickstart.py
.venv/bin/python -m unittest discover -s tests -v
