"""After installation, run this script from any working directory.
This deliberately short synthetic smoke run is NOT a complete evaluation.
"""
import subprocess,sys
from datetime import datetime
from uuid import uuid4
from pathlib import Path
PROJECT_ROOT=Path(__file__).resolve().parents[1]
run_dir='runs/demo_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6]

def run(*args):subprocess.run([sys.executable,'-m','rtvnet',*args],check=True,cwd=PROJECT_ROOT)
# STEP 1. Generate a labelled synthetic engineering fixture.
run('demo','--out','data/demo')
# STEP 2. Exercise all four ablations, using one held-out fold and two epochs.
run('ablate','--data','data/demo/windows.npz','--out',run_dir,
    '--epochs','2','--seeds','11','--max-folds','1')
# STEP 3. Plot actual network outputs and measure actual model size/latency.
cp=run_dir+'/rtvnet/seed_11/fold_0/best.pt'
run('explain','--data','data/demo/windows.npz','--checkpoint',cp,'--out',run_dir+'/explanation')
run('benchmark','--data','data/demo/windows.npz','--checkpoint',cp,'--out',run_dir+'/benchmark.json',
    '--warmup','5','--repeats','20')
# STEP 4. Export measured summaries; incomplete-CV and synthetic flags are retained.
run('report','--runs',run_dir,'--out',run_dir+'/summary.csv')
print('Synthetic smoke workflow finished. Outputs:',PROJECT_ROOT/run_dir)
print('See START_HERE.md and README.md before using real data.')
